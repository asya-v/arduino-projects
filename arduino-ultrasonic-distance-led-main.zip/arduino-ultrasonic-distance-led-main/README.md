# HC-SR04 Distance Controlled LED

## Overview

This Arduino project uses an HC-SR04 ultrasonic sensor to measure distance and adjust LED brightness.

The closer an object is to the sensor, the brighter the LED becomes.

---

## Why I Built It

I built this project to learn:

- Arduino programming
- PWM output
- Ultrasonic distance measurement
- Sensor integration

---

## Components

- Arduino Uno
- HC-SR04 ultrasonic sensor
- LED
- 220Ω resistor
- Breadboard
- Jumper wires

---

## How It Works

The HC-SR04 measures the distance to an object.

The Arduino converts the measured distance into a PWM value.

Distance:
- 5 cm → maximum brightness
- 50 cm → minimum brightness

The LED brightness changes automatically as the object moves.

---

## Wiring

| Component | Arduino Pin |
|------------|------------|
| Trig       | D9         |
| Echo       | D10        |
| LED        | D3         |
| VCC        | 5V         |
| GND        | GND        |

---

## Images

### Project Setup

![Setup](images/setup.jpg)

### Wiring Diagram

![Wiring](images/wiring.jpg)

---

## Code

The Arduino sketch is located in:

```text
code/distance_led.ino
```

## What I Learned

- Connected HC-SR04 to Arduino
- Used pulseIn()
- Used PWM
